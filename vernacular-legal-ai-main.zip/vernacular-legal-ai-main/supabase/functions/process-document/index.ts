import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const formData = await req.formData();
    const file = formData.get('file') as File;
    const fileName = formData.get('fileName') as string;

    if (!file) {
      throw new Error('No file provided');
    }

    if (!GEMINI_API_KEY) {
      throw new Error('Gemini API key not configured');
    }

    console.log(`Processing document: ${fileName}, Type: ${file.type}, Size: ${file.size}`);

    let documentText = '';
    let isImageDocument = false;

    // Handle different file types
    if (file.type.includes('image/')) {
      console.log('Processing image with OCR...');
      isImageDocument = true;
      
      // Convert image to base64 for Gemini Vision API
      const arrayBuffer = await file.arrayBuffer();
      const base64Image = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
      
      // Use Gemini Vision API for OCR
      const visionPrompt = `
      Please extract all text from this legal document image. 
      Return ONLY the extracted text content without any additional commentary or formatting.
      If the image contains a legal document, extract all readable text including:
      - Headers and titles
      - Body text and clauses
      - Dates, amounts, and numbers
      - Signatures and witness information
      - Any stamps or official markings text
      
      Extract the text as accurately as possible:
      `;

      const visionResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: visionPrompt },
              {
                inline_data: {
                  mime_type: file.type,
                  data: base64Image
                }
              }
            ]
          }],
          generationConfig: {
            temperature: 0.1,
            topK: 32,
            topP: 1,
            maxOutputTokens: 2048,
          },
        }),
      });

      if (!visionResponse.ok) {
        const errorText = await visionResponse.text();
        console.error('Gemini Vision API error:', errorText);
        throw new Error(`OCR processing failed: ${visionResponse.status}`);
      }

      const visionData = await visionResponse.json();
      documentText = visionData.candidates[0].content.parts[0].text;
      console.log('OCR extraction completed, text length:', documentText.length);

    } else if (file.type.includes('pdf') || file.type.includes('document') || 
               fileName.toLowerCase().endsWith('.pdf') || fileName.toLowerCase().endsWith('.doc') || 
               fileName.toLowerCase().endsWith('.docx')) {
      
      console.log('Processing binary document...');
      // For PDFs and Word documents, try to extract text
      // This is a simplified approach - in production, you'd use proper PDF/Word parsing libraries
      
      try {
        const text = await file.text();
        // Check if the extracted text is readable
        if (text.length > 50 && !/[\x00-\x08\x0E-\x1F\x7F-\xFF]/.test(text.substring(0, 100))) {
          documentText = text;
        } else {
          throw new Error('Binary content detected');
        }
      } catch (error) {
        // If direct text extraction fails, inform about the limitation
        throw new Error('This PDF or document appears to be encoded or contains binary content. Please try converting it to a text format, or use an image screenshot of the document instead.');
      }

    } else {
      // For text files
      console.log('Processing text document...');
      documentText = await file.text();
    }

    if (!documentText || documentText.trim().length === 0) {
      throw new Error('No text content could be extracted from the document');
    }

    // Analyze the extracted text with Gemini
    console.log('Analyzing document with Gemini...');
    const analysisPrompt = `
    You are an Expert Legal Document Analysis AI. Analyze the following ${isImageDocument ? 'OCR-extracted text from a legal document image' : 'legal document'} comprehensively and provide a detailed response in JSON format:

    Document Text: ${documentText}

    Please analyze this document thoroughly and return a JSON response with the following structure:
    {
      "originalLanguage": "detected language (Telugu, Tamil, Hindi, English, etc.)",
      "translatedText": "full English translation if not in English, otherwise empty string",
      "summary": "comprehensive summary of the document (3-4 sentences)",
      "simplifiedText": "simplified explanation in easy language that anyone can understand",
      "riskLevel": "low|medium|high",
      "riskFactors": ["array of specific risk factors, legal vulnerabilities, and potential problems identified"],
      "keyFindings": ["array of the most important findings and clauses"],
      "recommendations": ["array of specific actionable recommendations to protect interests"],
      "audioSummary": "brief summary suitable for text-to-speech (2-3 sentences)",
      "legalIssues": ["array of potential legal issues, compliance problems, and missing elements"],
      "documentType": "specific type of legal document (e.g., sale deed, rental agreement, employment contract, etc.)",
      "mistakes": ["array of errors, inconsistencies, missing clauses, or problematic terms found in the document"],
      "missingClauses": ["array of important clauses that should be present but are missing"],
      "urgentActions": ["array of urgent actions that need immediate attention"]
    }

    **CRITICAL ANALYSIS REQUIREMENTS:**
    1. **Mistake Detection**: Carefully identify any errors, typos, inconsistent dates, contradictory clauses, mathematical errors, or legal inconsistencies
    2. **Missing Elements**: Check for essential clauses, signatures, dates, witness requirements, stamps, registration details
    3. **Risk Assessment**: Evaluate financial risks, legal enforceability, compliance with local laws
    4. **Language Translation**: If the document contains regional language, provide accurate English translation
    5. **Legal Compliance**: Check against Indian legal requirements and standards
    6. **Actionable Insights**: Provide specific, practical recommendations for improving the document
    7. **Urgency Assessment**: Identify any time-sensitive issues that need immediate attention
    ${isImageDocument ? '8. **OCR Quality**: Account for potential OCR errors in text extraction and note if any text seems unclear' : ''}

    Be thorough, accurate, and focus on protecting the user's legal and financial interests.
    `;

    const analysisResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: analysisPrompt
          }]
        }],
        generationConfig: {
          temperature: 0.3,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 2048,
        },
      }),
    });

    if (!analysisResponse.ok) {
      const errorText = await analysisResponse.text();
      console.error('Gemini Analysis API error:', errorText);
      throw new Error(`Document analysis failed: ${analysisResponse.status}`);
    }

    const analysisData = await analysisResponse.json();
    const generatedText = analysisData.candidates[0].content.parts[0].text;
    
    // Extract JSON from the response
    const jsonMatch = generatedText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No valid JSON found in analysis response');
    }

    const analysisResult = JSON.parse(jsonMatch[0]);
    
    // Add metadata about processing method
    analysisResult.processingMethod = isImageDocument ? 'OCR' : 'Text Extraction';
    analysisResult.extractedTextLength = documentText.length;
    
    console.log('Document analysis completed successfully');
    
    return new Response(JSON.stringify(analysisResult), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in process-document function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});