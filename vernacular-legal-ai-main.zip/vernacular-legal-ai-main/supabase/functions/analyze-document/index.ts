import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY');

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { documentText, fileName } = await req.json();

    if (!GEMINI_API_KEY) {
      throw new Error('Gemini API key not configured');
    }

    console.log(`Analyzing document: ${fileName}`);

    const prompt = `
    You are an Expert Legal Document Analysis AI. Analyze the following document comprehensively and provide a detailed response in JSON format:

    Document Text: ${documentText}

    Please analyze this document thoroughly and return a JSON response with the following structure:
    {
      "originalLanguage": "detected language (Telugu, Tamil, Hindi, English, etc.)",
      "translatedText": "full English translation if not in English, otherwise empty string",
      "summary": "comprehensive summary of the document (3-4 sentences)",
      "simplifiedText": "simplified explanation in easy language that anyone can understand",
      "riskLevel": "low|medium|high",
      "riskFactors": ["array of specific risk factors, legal vulnerabilities, and potential problems identified"],
      "keyFindings": ["array of the most important findings and clauses"],
      "recommendations": ["array of specific actionable recommendations to protect interests"],
      "audioSummary": "brief summary suitable for text-to-speech (2-3 sentences)",
      "legalIssues": ["array of potential legal issues, compliance problems, and missing elements"],
      "documentType": "specific type of legal document (e.g., sale deed, rental agreement, employment contract, etc.)",
      "mistakes": ["array of errors, inconsistencies, missing clauses, or problematic terms found in the document"],
      "missingClauses": ["array of important clauses that should be present but are missing"],
      "urgentActions": ["array of urgent actions that need immediate attention"]
    }

    **CRITICAL ANALYSIS REQUIREMENTS:**
    1. **Mistake Detection**: Carefully identify any errors, typos, inconsistent dates, contradictory clauses, mathematical errors, or legal inconsistencies
    2. **Missing Elements**: Check for essential clauses, signatures, dates, witness requirements, stamps, registration details
    3. **Risk Assessment**: Evaluate financial risks, legal enforceability, compliance with local laws
    4. **Language Translation**: If the document contains regional language, provide accurate English translation
    5. **Legal Compliance**: Check against Indian legal requirements and standards
    6. **Actionable Insights**: Provide specific, practical recommendations for improving the document
    7. **Urgency Assessment**: Identify any time-sensitive issues that need immediate attention

    Be thorough, accurate, and focus on protecting the user's legal and financial interests.
    `;

    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: prompt
          }]
        }],
        generationConfig: {
          temperature: 0.3,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 2048,
        },
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Gemini API error:', errorText);
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = await response.json();
    const generatedText = data.candidates[0].content.parts[0].text;
    
    // Extract JSON from the response
    const jsonMatch = generatedText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No valid JSON found in Gemini response');
    }

    const analysisResult = JSON.parse(jsonMatch[0]);
    
    console.log('Document analysis completed successfully');
    
    return new Response(JSON.stringify(analysisResult), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in analyze-document function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});