import { LegalDocumentVerifier } from './LegalDocumentVerifier';

const Index = () => {
  return <LegalDocumentVerifier />;
};

export default Index;
