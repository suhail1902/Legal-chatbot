import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { MapPin, ExternalLink, FileText, Gavel } from 'lucide-react';

interface LocationVerificationFormProps {
  onVerificationComplete: (verificationData: VerificationData) => void;
  onCancel: () => void;
}

interface VerificationData {
  state: string;
  district: string;
  verificationSteps: string[];
  courtWebsites: Array<{
    name: string;
    url: string;
    description: string;
  }>;
  additionalResources: Array<{
    name: string;
    url: string;
    description: string;
  }>;
}

const indianStates = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
  'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
  'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
  'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Delhi', 'Chandigarh', 'Dadra and Nagar Haveli', 'Daman and Diu',
  'Jammu and Kashmir', 'Ladakh', 'Lakshadweep', 'Puducherry'
];

const stateData = {
  'Telangana': {
    districts: ['Hyderabad', 'Secunderabad', 'Warangal', 'Nizamabad', 'Khammam', 'Karimnagar', 'Ramagundam', 'Mahbubnagar', 'Nalgonda', 'Adilabad'],
    courtWebsites: [
      {
        name: 'Telangana High Court',
        url: 'https://hc.ts.nic.in/',
        description: 'Official website of Telangana High Court for case status and judgments'
      },
      {
        name: 'Telangana District Courts',
        url: 'https://districts.ecourts.gov.in/telangana',
        description: 'District court case status and information'
      }
    ]
  },
  'Andhra Pradesh': {
    districts: ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Rajahmundry', 'Tirupati', 'Kadapa', 'Anantapur', 'Eluru'],
    courtWebsites: [
      {
        name: 'Andhra Pradesh High Court',
        url: 'https://hc.ap.nic.in/',
        description: 'Official website of Andhra Pradesh High Court'
      }
    ]
  },
  'Karnataka': {
    districts: ['Bangalore Urban', 'Bangalore Rural', 'Mysore', 'Hubli-Dharwad', 'Mangalore', 'Belgaum', 'Gulbarga', 'Bellary', 'Bijapur', 'Shimoga'],
    courtWebsites: [
      {
        name: 'Karnataka High Court',
        url: 'https://karnatakajudiciary.kar.nic.in/',
        description: 'Official website of Karnataka High Court'
      }
    ]
  },
  'Tamil Nadu': {
    districts: ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Tiruppur', 'Vellore', 'Erode', 'Thoothukudi'],
    courtWebsites: [
      {
        name: 'Madras High Court',
        url: 'https://hcmadras.tn.nic.in/',
        description: 'Official website of Madras High Court'
      }
    ]
  },
  'Maharashtra': {
    districts: ['Mumbai City', 'Mumbai Suburban', 'Pune', 'Nagpur', 'Thane', 'Nashik', 'Aurangabad', 'Solapur', 'Amravati', 'Nanded'],
    courtWebsites: [
      {
        name: 'Bombay High Court',
        url: 'https://bombayhighcourt.nic.in/',
        description: 'Official website of Bombay High Court'
      }
    ]
  }
};

export const LocationVerificationForm = ({ onVerificationComplete, onCancel }: LocationVerificationFormProps) => {
  const [selectedState, setSelectedState] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');

  const handleVerification = () => {
    if (!selectedState || !selectedDistrict) return;

    const stateInfo = stateData[selectedState as keyof typeof stateData];
    
    const verificationSteps = [
      'Visit the Sub-Registrar Office in your district to obtain Encumbrance Certificate (EC)',
      'Search for property disputes in district court records',
      'Check High Court records for any pending litigation',
      'Verify property ownership through revenue department records',
      'Cross-check with local police station for any criminal cases related to property',
      'Consult with a local property lawyer familiar with state laws'
    ];

    const additionalResources = [
      {
        name: 'E-Courts National Judicial Data Grid',
        url: 'https://njdg.ecourts.gov.in/',
        description: 'Search for cases across all courts in India'
      },
      {
        name: 'Supreme Court of India',
        url: 'https://main.sci.gov.in/',
        description: 'Supreme Court case status and judgments'
      },
      {
        name: 'Legal Services Authority',
        url: 'https://nalsa.gov.in/',
        description: 'Free legal aid and services information'
      },
      {
        name: 'Property Registration Portal',
        url: `https://${selectedState.toLowerCase().replace(/\s+/g, '')}.gov.in/`,
        description: 'State-specific property registration and verification'
      }
    ];

    const verificationData: VerificationData = {
      state: selectedState,
      district: selectedDistrict,
      verificationSteps,
      courtWebsites: stateInfo?.courtWebsites || [],
      additionalResources
    };

    onVerificationComplete(verificationData);
  };

  const selectedStateData = stateData[selectedState as keyof typeof stateData];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          Legal Verification - Location Details
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="state">Select State</Label>
            <Select value={selectedState} onValueChange={setSelectedState}>
              <SelectTrigger>
                <SelectValue placeholder="Choose your state" />
              </SelectTrigger>
              <SelectContent>
                {indianStates.map((state) => (
                  <SelectItem key={state} value={state}>
                    {state}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="district">Select District</Label>
            <Select 
              value={selectedDistrict} 
              onValueChange={setSelectedDistrict}
              disabled={!selectedState}
            >
              <SelectTrigger>
                <SelectValue placeholder="Choose your district" />
              </SelectTrigger>
              <SelectContent>
                {selectedStateData?.districts.map((district) => (
                  <SelectItem key={district} value={district}>
                    {district}
                  </SelectItem>
                )) || []}
              </SelectContent>
            </Select>
          </div>
        </div>

        {selectedState && selectedStateData && (
          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-medium mb-2 flex items-center gap-2">
              <Gavel className="w-4 h-4" />
              Available Court Resources for {selectedState}
            </h4>
            <div className="space-y-2">
              {selectedStateData.courtWebsites.map((court, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm">{court.name}</span>
                  <Button size="sm" variant="outline" asChild>
                    <a href={court.url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-3 h-3 mr-1" />
                      Visit
                    </a>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-3">
          <Button 
            onClick={handleVerification}
            disabled={!selectedState || !selectedDistrict}
            className="flex-1"
          >
            <FileText className="w-4 h-4 mr-2" />
            Get Verification Instructions
          </Button>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};