import { useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, FileText, AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface DocumentUploadProps {
  onDocumentUpload: (file: File) => void;
  isAnalyzing: boolean;
}

export const DocumentUpload = ({ onDocumentUpload, isAnalyzing }: DocumentUploadProps) => {
  const [dragActive, setDragActive] = useState(false);
  const { toast } = useToast();

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    const file = files[0];

    if (file) {
      // Check file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please upload a file smaller than 10MB.",
          variant: "destructive",
        });
        return;
      }

      // Accept various document types including images
      const validTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain',
        'text/rtf',
        'application/rtf',
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/webp',
        'image/bmp',
        'image/tiff'
      ];
      
      const isValidType = validTypes.some(type => file.type === type) || 
                         file.type.includes('pdf') || 
                         file.type.includes('document') || 
                         file.type.includes('text') ||
                         file.type.includes('image/') ||
                         file.name.toLowerCase().endsWith('.pdf') ||
                         file.name.toLowerCase().endsWith('.doc') ||
                         file.name.toLowerCase().endsWith('.docx') ||
                         file.name.toLowerCase().endsWith('.txt') ||
                         file.name.toLowerCase().endsWith('.jpg') ||
                         file.name.toLowerCase().endsWith('.jpeg') ||
                         file.name.toLowerCase().endsWith('.png') ||
                         file.name.toLowerCase().endsWith('.webp');

      if (isValidType) {
        onDocumentUpload(file);
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload a PDF, DOC, DOCX, text document, or image file.",
          variant: "destructive",
        });
      }
    }
  }, [onDocumentUpload, toast]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onDocumentUpload(file);
    }
  };

  return (
    <Card className="border-2 border-dashed transition-colors duration-200 hover:border-primary">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-primary">
          <FileText className="w-6 h-6" />
          Upload Legal Document
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div
          className={`relative p-8 rounded-lg border-2 border-dashed transition-all duration-200 ${
            dragActive 
              ? 'border-primary bg-primary/5' 
              : 'border-muted-foreground/25 hover:border-primary/50'
          }`}
          onDragEnter={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setDragActive(true);
          }}
          onDragLeave={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setDragActive(false);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            e.stopPropagation();
          }}
          onDrop={handleDrop}
        >
          <div className="text-center space-y-4">
            <Upload className="w-12 h-12 mx-auto text-muted-foreground" />
            <div>
              <p className="text-lg font-medium">Drop your legal document here</p>
              <p className="text-sm text-muted-foreground mt-1">
                Supports PDF, DOC, DOCX, text files, and images (JPG, PNG) up to 10MB
              </p>
            </div>
            <div className="flex items-center justify-center gap-4">
              <input
                type="file"
                id="document-upload"
                className="sr-only"
                accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.webp"
                onChange={handleFileInput}
                disabled={isAnalyzing}
              />
              <label htmlFor="document-upload">
                <Button
                  type="button"
                  disabled={isAnalyzing}
                  className="cursor-pointer"
                  asChild
                >
                  <span>
                    {isAnalyzing ? 'Analyzing...' : 'Choose File'}
                  </span>
                </Button>
              </label>
            </div>
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-legal-trust/10 rounded-lg border border-legal-trust/20">
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-legal-trust mt-0.5 flex-shrink-0" />
            <div className="text-xs text-legal-trust-foreground">
              <p className="font-medium">Privacy Notice:</p>
              <p>Your documents are processed securely and are not stored permanently. All analysis is confidential.</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};