import { Scale, Shield, Globe } from 'lucide-react';

export const LegalHeader = () => {
  return (
    <header className="bg-gradient-to-r from-primary to-primary/90 text-primary-foreground">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 bg-primary-foreground/10 rounded-full">
              <Scale className="w-8 h-8" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold">
              Legal Document Verification AI
            </h1>
          </div>
          
          <p className="text-lg md:text-xl text-primary-foreground/90 max-w-3xl mx-auto">
            Analyze, translate, and understand legal documents with AI-powered insights and risk assessment
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-6 mt-6 text-sm">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4" />
              Multi-language Support
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Secure & Confidential
            </div>
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4" />
              Legal Risk Assessment
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};