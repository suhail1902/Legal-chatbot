import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  ExternalLink, 
  FileText, 
  CheckCircle, 
  AlertTriangle,
  Download,
  Globe
} from 'lucide-react';

interface VerificationData {
  state: string;
  district: string;
  verificationSteps: string[];
  courtWebsites: Array<{
    name: string;
    url: string;
    description: string;
  }>;
  additionalResources: Array<{
    name: string;
    url: string;
    description: string;
  }>;
}

interface VerificationInstructionsProps {
  verificationData: VerificationData;
  onDownloadInstructions: () => void;
  onStartNewVerification: () => void;
}

export const VerificationInstructions = ({ 
  verificationData, 
  onDownloadInstructions,
  onStartNewVerification 
}: VerificationInstructionsProps) => {
  return (
    <div className="space-y-6">
      {/* Location Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <MapPin className="w-5 h-5" />
              Legal Verification Instructions
            </span>
            <div className="flex items-center gap-2">
              <Badge variant="outline">{verificationData.state}</Badge>
              <Badge variant="secondary">{verificationData.district}</Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Follow these step-by-step instructions to verify legal disputes and court cases for your location.
          </p>
        </CardContent>
      </Card>

      {/* Step-by-Step Instructions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            Verification Steps
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            {verificationData.verificationSteps.map((step, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-medium flex-shrink-0 mt-0.5">
                  {index + 1}
                </div>
                <p className="text-sm leading-relaxed">{step}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Court Websites */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            State-Specific Court Websites
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {verificationData.courtWebsites.map((court, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">{court.name}</h4>
                <Button size="sm" variant="outline" asChild>
                  <a href={court.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-3 h-3 mr-1" />
                    Visit Website
                  </a>
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">{court.description}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Additional Resources */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Additional Legal Resources
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {verificationData.additionalResources.map((resource, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">{resource.name}</h4>
                <Button size="sm" variant="outline" asChild>
                  <a href={resource.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-3 h-3 mr-1" />
                    Access
                  </a>
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">{resource.description}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Important Notes */}
      <Card className="border-legal-trust/30 bg-legal-trust/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-legal-trust flex-shrink-0 mt-0.5" />
            <div className="space-y-2">
              <p className="font-medium text-legal-trust-foreground">Important Notes:</p>
              <ul className="text-sm text-legal-trust-foreground/80 space-y-1">
                <li>• Encumbrance Certificate (EC) only shows registered transactions, not private disputes</li>
                <li>• Always search multiple court databases for comprehensive verification</li>
                <li>• Consult with a local lawyer familiar with state-specific property laws</li>
                <li>• Keep all verification documents for your records</li>
                <li>• Some court records may take time to update online</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button onClick={onDownloadInstructions} className="flex-1">
          <Download className="w-4 h-4 mr-2" />
          Download Instructions
        </Button>
        <Button variant="outline" onClick={onStartNewVerification}>
          New Verification
        </Button>
      </div>
    </div>
  );
};