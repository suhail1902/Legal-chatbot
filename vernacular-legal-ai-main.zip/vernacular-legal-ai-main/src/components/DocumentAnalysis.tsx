import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  FileText, 
  Globe, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Download,
  Volume2,
  Eye
} from 'lucide-react';

export interface AnalysisResult {
  originalLanguage: string;
  translatedText?: string;
  summary: string;
  simplifiedText: string;
  riskLevel: 'low' | 'medium' | 'high';
  riskFactors: string[];
  keyFindings: string[];
  recommendations: string[];
  audioSummary: string;
  legalIssues: string[];
  documentType: string;
  mistakes?: string[];
  missingClauses?: string[];
  urgentActions?: string[];
}

interface DocumentAnalysisProps {
  result: AnalysisResult;
  fileName: string;
  onDownloadReport: () => void;
  onPlayAudio: () => void;
  onRequestDispute: () => void;
  onRequestVerification: () => void;
}

export const DocumentAnalysis = ({ 
  result, 
  fileName, 
  onDownloadReport, 
  onPlayAudio,
  onRequestDispute,
  onRequestVerification
}: DocumentAnalysisProps) => {
  const getRiskBadgeVariant = (risk: string) => {
    switch (risk) {
      case 'low': return 'default';
      case 'medium': return 'secondary';
      case 'high': return 'destructive';
      default: return 'default';
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'low': return <CheckCircle className="w-4 h-4" />;
      case 'medium': return <AlertTriangle className="w-4 h-4" />;
      case 'high': return <XCircle className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-risk-low';
      case 'medium': return 'text-risk-medium';
      case 'high': return 'text-risk-high';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Document Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Document Analysis Complete
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Globe className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Original Language: <strong>{result.originalLanguage}</strong></span>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={onPlayAudio}>
                <Volume2 className="w-4 h-4 mr-2" />
                Audio Summary
              </Button>
              <Button size="sm" onClick={onDownloadReport}>
                <Download className="w-4 h-4 mr-2" />
                Download Report
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Risk Assessment */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Risk Assessment
            </span>
            <div className="flex items-center gap-2">
              <span className={getRiskColor(result.riskLevel)}>
                {getRiskIcon(result.riskLevel)}
              </span>
              <Badge 
                variant={getRiskBadgeVariant(result.riskLevel)}
                className="capitalize"
              >
                {result.riskLevel} Risk
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {result.riskFactors.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">Identified Risk Factors:</h4>
              <ul className="space-y-1">
                {result.riskFactors.map((factor, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <span className="w-1.5 h-1.5 bg-risk-medium rounded-full mt-2 flex-shrink-0" />
                    {factor}
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {result.recommendations.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">Recommended Actions:</h4>
              <ul className="space-y-1">
                {result.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Mistakes and Issues */}
          {(result.mistakes && result.mistakes.length > 0) && (
            <div>
              <h4 className="font-medium mb-2 text-destructive">Document Mistakes Found:</h4>
              <ul className="space-y-1">
                {result.mistakes.map((mistake, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <XCircle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                    <span className="text-destructive">{mistake}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {(result.missingClauses && result.missingClauses.length > 0) && (
            <div>
              <h4 className="font-medium mb-2 text-orange-600">Missing Essential Clauses:</h4>
              <ul className="space-y-1">
                {result.missingClauses.map((clause, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <AlertTriangle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                    <span className="text-orange-600">{clause}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {(result.urgentActions && result.urgentActions.length > 0) && (
            <div>
              <h4 className="font-medium mb-2 text-red-600">Urgent Actions Required:</h4>
              <ul className="space-y-1">
                {result.urgentActions.map((action, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <span className="w-1.5 h-1.5 bg-red-600 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-red-600 font-medium">{action}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-6 space-y-3">
            <Button onClick={onRequestVerification} className="w-full" variant="outline">
              Verify Legal Disputes by Location
            </Button>
            {result.riskLevel !== 'low' && (
              <Button onClick={onRequestDispute} className="w-full">
                Request Dispute Assistance Plan
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Document Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Document Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-medium mb-2">Quick Summary:</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {result.summary}
            </p>
          </div>
          
          <Separator />
          
          <div>
            <h4 className="font-medium mb-2">Key Findings:</h4>
            <ul className="space-y-1">
              {result.keyFindings.map((finding, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <span className="w-1.5 h-1.5 bg-legal-trust rounded-full mt-2 flex-shrink-0" />
                  {finding}
                </li>
              ))}
            </ul>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-2">Simplified Version:</h4>
            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm leading-relaxed">
                {result.simplifiedText}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Legal Disclaimer */}
      <Card className="border-legal-trust/30 bg-legal-trust/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-legal-trust flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-legal-trust-foreground mb-1">Legal Disclaimer:</p>
              <p className="text-legal-trust-foreground/80 leading-relaxed">
                This AI assistant provides general legal guidance based on document analysis and public resources. 
                It does not replace professional legal advice. Please consult a qualified lawyer for official legal matters.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};